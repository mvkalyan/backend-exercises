package com.example.movieSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieSpringBootApplication.class, args);
	}

}
