package com.example.movieSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
