package com.niit.course13Sprint4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Course13Sprint4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
