package com.niit.Course13Sprint1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Course13Sprint1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
