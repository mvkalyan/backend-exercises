package com.sprint4.productdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductdetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
