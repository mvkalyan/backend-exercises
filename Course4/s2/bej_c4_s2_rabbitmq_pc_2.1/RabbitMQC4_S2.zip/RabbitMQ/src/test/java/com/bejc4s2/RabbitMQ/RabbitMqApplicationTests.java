package com.bejc4s2.RabbitMQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
