package otg.niit.dao;

import otg.niit.model.Employee;

import java.util.List;

public interface IEmpDao {

    public boolean addEmp(Employee e);
    public List<Employee> getAllEmp();

}
