package otg.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import otg.niit.dao.IEmpDao;
import otg.niit.model.Employee;

@Controller
@RequestMapping("/")
public class EmployeeController {

    @Autowired
    private IEmpDao empdao;

    @GetMapping("/")
    public String getHomePage(){
        return "index";
    }

    @PostMapping("/saveEmp")
    public String saveEmp(@ModelAttribute("emp")Employee emp, ModelMap model){
        empdao.addEmp(emp);

        model.addAttribute("empList",empdao.getAllEmp());

        return "welcome";
    }

}
