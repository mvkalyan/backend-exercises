package com.niit.usermovieservice.service;

import com.niit.usermovieservice.domain.Movie;
import com.niit.usermovieservice.domain.User;
import com.niit.usermovieservice.exception.UserAlreadyExistsException;
import com.niit.usermovieservice.exception.UserNotFoundException;

import java.util.List;

public interface UserMovieService
{
public User registerUser(User user) throws UserAlreadyExistsException;
public User saveUserMovie(Movie movie,String email) throws UserNotFoundException;
public List<User> getAllUser();


}
