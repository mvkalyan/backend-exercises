package com.niit.usermovieservice.controller;

import com.niit.usermovieservice.domain.Movie;
import com.niit.usermovieservice.domain.User;
import com.niit.usermovieservice.exception.UserAlreadyExistsException;
import com.niit.usermovieservice.service.UserMovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/api/v1/")
public class UserMovieController
{
    private ResponseEntity responseEntity;
    private UserMovieService userMovieService;
   @Autowired

    public UserMovieController(UserMovieService userMovieService) {
        this.userMovieService = userMovieService;
    }
    @PostMapping("registeruser")
    public ResponseEntity<?> saveUser(@RequestBody User user) throws UserAlreadyExistsException
    {
        try
        {
            userMovieService.registerUser(user);
            responseEntity=new ResponseEntity<>(user, HttpStatus.CREATED);
        }
        catch (UserAlreadyExistsException userAlreadyExistsException)
        {
            throw userAlreadyExistsException;
        }
        catch (Exception e)
        {
            responseEntity=new ResponseEntity<>(e,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    @PostMapping("savemovie/{email}")
    public ResponseEntity<?> saveMovie(@RequestBody Movie movie, @PathVariable String email) throws UserAlreadyExistsException
    {
      try
      {
         User user= userMovieService.saveUserMovie(movie,email);
          responseEntity=new ResponseEntity<>(user, HttpStatus.OK);

      }
      catch (Exception e)
      {
          responseEntity=new ResponseEntity<>("Error try Again",HttpStatus.INTERNAL_SERVER_ERROR);
      }
      return responseEntity;
    }

    @GetMapping("allusers")
    public ResponseEntity<?> getALlUsers()
    {
        try
        {
            responseEntity=new ResponseEntity<>(userMovieService.getAllUser(),HttpStatus.OK);
        }
        catch (Exception e)
        {
            responseEntity=new ResponseEntity<>("Error try Again",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

}
