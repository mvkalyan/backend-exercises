package com.niit.usermovieservice.domain;

import lombok.*;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Movie
{
    private String movieName;
    private String genre;
}
