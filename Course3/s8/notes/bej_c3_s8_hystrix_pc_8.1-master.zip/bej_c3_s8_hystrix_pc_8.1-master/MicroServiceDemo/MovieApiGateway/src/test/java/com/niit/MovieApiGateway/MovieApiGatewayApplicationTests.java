package com.niit.MovieApiGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
