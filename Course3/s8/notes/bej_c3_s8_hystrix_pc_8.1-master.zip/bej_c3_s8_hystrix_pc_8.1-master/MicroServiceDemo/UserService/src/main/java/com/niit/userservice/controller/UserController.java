package com.niit.userservice.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.niit.userservice.domain.User;
import com.niit.userservice.exception.UserNotFoundException;
import com.niit.userservice.service.SecurityTokenGenerator;
import com.niit.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v2/")
public class UserController
{
    private ResponseEntity responseEntity;
    private UserService userService;
    private SecurityTokenGenerator securityTokenGenerator;
    @Autowired
    public UserController(UserService userService, SecurityTokenGenerator securityTokenGenerator)
    {
        this.userService = userService;
        this.securityTokenGenerator = securityTokenGenerator;
    }
    @PostMapping("register")
    public ResponseEntity<?> saveUser(@RequestBody User user)
    {
        userService.saveUser(user);
        responseEntity=new ResponseEntity(user, HttpStatus.CREATED);
        return responseEntity;
    }
    @PostMapping("login")
    @HystrixCommand(fallbackMethod ="fallbackLogin")
    @HystrixProperty(name ="execution.isolation.thread.timeoutInMilliseconds",value ="60000")
    public ResponseEntity loginUser(@RequestBody User userDetails) throws UserNotFoundException
    {
        Map<String,String> map=null;
        try
        {
            User userObj=userService.findByUserNameAndPassword(userDetails.getUserName(),userDetails.getPassword());
            System.out.println("i AM GOING TO SLEEP");
           // Thread.sleep(70000);
            System.out.println("I have resumed");
            if(userObj.getUserName().equals(userDetails.getUserName()))
            {
                map=securityTokenGenerator.generateToken(userDetails);
            }
            responseEntity=new ResponseEntity(map,HttpStatus.OK);
        }
        catch (UserNotFoundException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            responseEntity=new ResponseEntity<>("Try again after Sometime ",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    public ResponseEntity<?> fallbackLogin(@RequestBody User userDetails) throws UserNotFoundException
    {
        String msg="login failed";
        return new ResponseEntity<>(msg,HttpStatus.BAD_REQUEST);
    }
    @GetMapping("api/v1/userservice/users")
    public ResponseEntity getAllUsers(HttpServletRequest request)
    {
        List<User> list=userService.getAllUser();
        responseEntity=new ResponseEntity<>(list, HttpStatus.OK);
        return responseEntity;
    }
}