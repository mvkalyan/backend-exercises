package com.niit.userservice.service;

import com.niit.userservice.domain.User;
import com.niit.userservice.exception.UserNotFoundException;

import java.util.List;

public interface UserService
{
    public User saveUser(User user);
    public User findByUserNameAndPassword(String userName,String password) throws UserNotFoundException;
    List<User> getAllUser();


}
