package com.niit.userservice.service;

import com.niit.userservice.domain.User;
import com.niit.userservice.exception.UserNotFoundException;
import com.niit.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService
{
    private UserRepository userRepository;
    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User userDetails)
    {
        return userRepository.save(userDetails);
    }

    @Override
    public User findByUserNameAndPassword(String userName, String password) throws UserNotFoundException
    {

        return userRepository.findByUserNameAndPassword(userName,password);

    }

    @Override
    public List<User> getAllUser()
    {
        return userRepository.findAll();
    }
}