package com.niit.usermovieservice.exception;

public class UserAlreadyExistsException extends Exception {
}
