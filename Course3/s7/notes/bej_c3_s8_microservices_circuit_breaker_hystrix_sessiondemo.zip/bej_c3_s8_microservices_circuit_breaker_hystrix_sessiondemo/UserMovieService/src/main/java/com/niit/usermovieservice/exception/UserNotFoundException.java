package com.niit.usermovieservice.exception;

public class UserNotFoundException extends Throwable {
}
