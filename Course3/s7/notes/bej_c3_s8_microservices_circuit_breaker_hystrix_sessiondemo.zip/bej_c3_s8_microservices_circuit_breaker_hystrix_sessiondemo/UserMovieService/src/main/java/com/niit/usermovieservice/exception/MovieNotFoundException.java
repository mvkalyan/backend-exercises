package com.niit.usermovieservice.exception;

public class MovieNotFoundException extends Throwable {
}
