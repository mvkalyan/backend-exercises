export MONGO_DATABASENAME=movie_db
export MONGO_URI=mongodb://localhost:27017/movie_db
