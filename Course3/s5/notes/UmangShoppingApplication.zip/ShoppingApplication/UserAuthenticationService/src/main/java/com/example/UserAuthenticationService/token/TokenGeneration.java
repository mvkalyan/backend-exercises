package com.example.UserAuthenticationService.token;

import com.example.UserAuthenticationService.domain.Customer;

import java.util.Map;

public interface TokenGeneration
{
    // Returns a Map
    public Map<String, String> generateToken(Customer customer);
}
