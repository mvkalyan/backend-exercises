package com.example.UserAuthenticationService.token;

import com.example.UserAuthenticationService.domain.Customer;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class TokenGeneratorImplementation implements TokenGeneration {
    @Override
    public Map<String, String> generateToken(Customer customer)
    {
        // OUTCOME
        Map<String, String> token = new HashMap<>();

        // Hash map to store user object
        Map<String, Object> userData = new HashMap<>();
        userData.put("userObject", customer);

        //TOKEN GENERATION
        String JWTToken = Jwts.builder()
                .setClaims(userData) // Require a map
                .setIssuedAt(new Date()) //Date issued
                .signWith(SignatureAlgorithm.HS512, "securityKey") // Specifies Algorithm
                .compact();
        token.put("token", JWTToken);
        return token;
    }
}
