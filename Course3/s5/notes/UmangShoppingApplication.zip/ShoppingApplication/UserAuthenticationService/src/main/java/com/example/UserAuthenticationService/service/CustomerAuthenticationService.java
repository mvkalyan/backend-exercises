package com.example.UserAuthenticationService.service;

import com.example.UserAuthenticationService.domain.Customer;
import com.example.UserAuthenticationService.exceptions.CustomerAlreadyExistException;
import com.example.UserAuthenticationService.exceptions.UnableToFindCustomerException;

public interface CustomerAuthenticationService
{
    // SAVE A CUSTOMER
    Customer saveCustomerDetails(Customer customer) throws CustomerAlreadyExistException;

    // FIND CUSTOMER
    Customer findCustomerByCustomerIDAndPassword(int customerID, String password) throws UnableToFindCustomerException;
}
