package com.example.UserAuthenticationService.controller;


import com.example.UserAuthenticationService.domain.Customer;
import com.example.UserAuthenticationService.exceptions.CustomerAlreadyExistException;
import com.example.UserAuthenticationService.exceptions.UnableToFindCustomerException;
import com.example.UserAuthenticationService.service.CustomerAuthenticationServiceImplementation;
import com.example.UserAuthenticationService.token.TokenGeneration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/authentication")
public class UserAuthenticationController
{
    // DEPENDENT ON
    @Autowired
    private CustomerAuthenticationServiceImplementation service;
    @Autowired
    private TokenGeneration tokenGeneration;


    // REGISTRATION
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Customer customer) throws CustomerAlreadyExistException
    {
        return new ResponseEntity<>(service.saveCustomerDetails(customer), HttpStatus.CREATED);
    }

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Customer customer) throws UnableToFindCustomerException {
        Customer customerFlag = service.findCustomerByCustomerIDAndPassword(customer.getCustomerID(), customer.getPassword());
        if(( customerFlag != null))
        {
            // ON SUCCESS
            Map<String, String> tokenGenerated = tokenGeneration.generateToken(customer);
            return new ResponseEntity<>(tokenGenerated, HttpStatus.OK);
        }
        else
        {
            // ON FAILURE
            return new ResponseEntity<>("Authentication failed",HttpStatus.NOT_FOUND);
        }
    }
}
