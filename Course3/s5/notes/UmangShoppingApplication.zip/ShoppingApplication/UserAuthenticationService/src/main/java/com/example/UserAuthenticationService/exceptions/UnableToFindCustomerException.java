package com.example.UserAuthenticationService.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT,reason = "OOPS! Invalid Credentials OR Customer may not exist.")
public class UnableToFindCustomerException extends Exception{ }
