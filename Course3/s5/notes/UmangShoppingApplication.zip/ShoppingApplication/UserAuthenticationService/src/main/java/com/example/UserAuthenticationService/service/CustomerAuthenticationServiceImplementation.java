package com.example.UserAuthenticationService.service;

import com.example.UserAuthenticationService.domain.Customer;
import com.example.UserAuthenticationService.exceptions.CustomerAlreadyExistException;
import com.example.UserAuthenticationService.exceptions.UnableToFindCustomerException;
import com.example.UserAuthenticationService.repository.CustomerAuthenticationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerAuthenticationServiceImplementation implements CustomerAuthenticationService
{
    //DEPENDENT ON
    @Autowired
    private CustomerAuthenticationRepository repository;

    @Override
    public Customer saveCustomerDetails(Customer customer) throws CustomerAlreadyExistException {
        // CHECKPOINT
        int customerID = customer.getCustomerID();
        if(repository.existsById(customerID))
            throw new CustomerAlreadyExistException();

        return repository.save(customer);
    }

    @Override
    public Customer findCustomerByCustomerIDAndPassword(int customerID, String password) throws UnableToFindCustomerException
    {
        Customer customer = repository.findByCustomerIDAndPassword(customerID,password);

        // CHECKPOINT
        if(customer == null)
            throw new UnableToFindCustomerException();

        return customer;
    }
}
