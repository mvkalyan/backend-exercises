package com.example.UserAuthenticationService.domain;

import lombok.Data;

import javax.persistence.Entity;

import javax.persistence.Id;

@Data
@Entity
public class Customer
{
    // PROPERTIES
    @Id
    private int customerID;
    private String password;
}
