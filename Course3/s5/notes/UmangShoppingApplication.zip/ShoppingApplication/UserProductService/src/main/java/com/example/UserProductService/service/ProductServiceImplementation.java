package com.example.UserProductService.service;

import com.example.UserProductService.domain.Customer;
import com.example.UserProductService.domain.Product;
import com.example.UserProductService.exception.CustomerAlreadyExistException;
import com.example.UserProductService.exception.UnableToFindCustomerException;
import com.example.UserProductService.exception.UnableToFindProductException;
import com.example.UserProductService.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class ProductServiceImplementation implements ProductService
{
    //DEPENDENT ON
    @Autowired
    private ProductRepository repository;

    @Override
    public Customer registerNewCustomer(Customer customer) throws CustomerAlreadyExistException
    {
        // CHECKPOINT
        if(repository.existsById(customer.getCustomerID()))
            throw new CustomerAlreadyExistException();
        return repository.insert(customer);
    }

    @Override
    public Customer saveCustomerProduct(Product product, int customerID) throws UnableToFindCustomerException {
        // CHECKPOINT
        if(!repository.existsById(customerID))
            throw new UnableToFindCustomerException();

        Customer customer = repository.findById(customerID).get();
        List<Product> productList = customer.getProducts();
        productList.add(product);
        customer.setProducts(productList);
        return repository.save(customer);
    }

    @Override
    public Customer deleteProduct(int customerID, final int productCode) throws UnableToFindCustomerException, UnableToFindProductException {
        boolean isProductPresent = false;
        // CHECKPOINT
        if(!repository.existsById(customerID))
            throw new UnableToFindCustomerException();

        Customer customer = repository.findById(customerID).get();
        List<Product> productList = customer.getProducts();

        isProductPresent = productList.removeIf((product) -> Objects.equals(product.getProductCode(), productCode));

        // CHECKPOINT
        if(!isProductPresent)
            throw new UnableToFindProductException();

        customer.setProducts(productList);
        return repository.save(customer);
    }

    @Override
    public List<Product> getAllProductsOfCustomer(int customerID) throws UnableToFindCustomerException {
        // CHECKPOINT
        if(!repository.existsById(customerID))
            throw new UnableToFindCustomerException();

        return repository.findById(customerID).get().getProducts();
    }
}
