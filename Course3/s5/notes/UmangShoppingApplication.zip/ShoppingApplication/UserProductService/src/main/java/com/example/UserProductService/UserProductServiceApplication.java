package com.example.UserProductService;

import com.example.UserProductService.filter.TokenFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class UserProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserProductServiceApplication.class, args);
	}

	@Bean
	public FilterRegistrationBean filteringJWT()
	{
		// Returns list of intercepted URLs with defined JWT Filter class
		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
		filterRegistrationBean.setFilter(new TokenFilter());
		filterRegistrationBean.addUrlPatterns("/save-product/{customerID}","/delete-product/{customerID}/{productCode}","/allProducts/{customerID}");

		return filterRegistrationBean;
	}

}
