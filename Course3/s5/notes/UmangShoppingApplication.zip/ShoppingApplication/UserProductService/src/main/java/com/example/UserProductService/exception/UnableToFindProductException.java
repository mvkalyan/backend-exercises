package com.example.UserProductService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT,reason = "OOPS! Cannot Find Product.")
public class UnableToFindProductException extends Exception{ }
