package com.example.UserProductService.service;


import com.example.UserProductService.domain.Customer;
import com.example.UserProductService.domain.Product;
import com.example.UserProductService.exception.CustomerAlreadyExistException;
import com.example.UserProductService.exception.UnableToFindCustomerException;
import com.example.UserProductService.exception.UnableToFindProductException;

import java.util.List;

public interface ProductService
{
    // Add a new customer
    Customer registerNewCustomer(Customer customer) throws CustomerAlreadyExistException;

    // Save products
    Customer saveCustomerProduct(Product product, int customerID) throws UnableToFindCustomerException;

    // Delete a product of a customer
    Customer deleteProduct(int customerID, int productCode) throws UnableToFindCustomerException, UnableToFindProductException;

    //Fetching all products of a customer
    List<Product>getAllProductsOfCustomer(int customerID) throws UnableToFindCustomerException;
}
