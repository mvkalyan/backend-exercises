package com.example.UserProductService.controller;

import com.example.UserProductService.domain.Customer;
import com.example.UserProductService.domain.Product;
import com.example.UserProductService.exception.CustomerAlreadyExistException;
import com.example.UserProductService.exception.UnableToFindCustomerException;
import com.example.UserProductService.exception.UnableToFindProductException;
import com.example.UserProductService.service.ProductServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController
{
    // DEPENDENT ON
    @Autowired
    ProductServiceImplementation service;

    // Registering a customer
    @PostMapping("/register")
    public ResponseEntity<?> registerACustomer(@RequestBody Customer customer) throws CustomerAlreadyExistException
    {
        return new ResponseEntity<>(service.registerNewCustomer(customer), HttpStatus.CREATED);
    }

    // Save products of a customer
    @PostMapping("/save-product/{customerID}")
    public ResponseEntity<?> saveProducts(@RequestBody Product product, @PathVariable int customerID) throws UnableToFindCustomerException {
        return new ResponseEntity<>(service.saveCustomerProduct(product, customerID),HttpStatus.FOUND);
    }

    // Delete products of a customer
    @DeleteMapping("/delete-product/{customerID}/{productCode}")
    public ResponseEntity<?> deleteProduct(@PathVariable int customerID, @PathVariable int productCode) throws UnableToFindCustomerException, UnableToFindProductException {
        return new ResponseEntity<>(service.deleteProduct(customerID,productCode),HttpStatus.OK);
    }

    // Get all products of a customer
    @GetMapping("/allProducts/{customerID}")
    public ResponseEntity<?> fetchAllProducts(@PathVariable int customerID) throws UnableToFindCustomerException
    {
        return new ResponseEntity<>(service.getAllProductsOfCustomer(customerID),HttpStatus.FOUND);
    }

}
