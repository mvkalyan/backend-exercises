package com.example.UserProductService.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
public class Product
{
    // PROPERTIES
    @Id
    private int productCode;
    private String productName, productDescription;
    private Boolean isInStock;
}
