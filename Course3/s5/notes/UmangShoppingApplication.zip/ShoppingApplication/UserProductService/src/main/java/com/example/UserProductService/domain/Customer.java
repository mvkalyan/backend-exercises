package com.example.UserProductService.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document
public class Customer
{
    // PROPERTIES
    @Id
    private int customerID;
    private String customerName, address, email, password;
    private List<Product> products;
}
