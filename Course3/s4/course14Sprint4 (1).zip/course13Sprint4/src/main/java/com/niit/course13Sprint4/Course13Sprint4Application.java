package com.niit.course13Sprint4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course13Sprint4Application {

	public static void main(String[] args) {
		SpringApplication.run(Course13Sprint4Application.class, args);
	}

}
